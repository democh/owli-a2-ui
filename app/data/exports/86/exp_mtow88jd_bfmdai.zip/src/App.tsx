import Page1 from "./pages/Page1";

export default function App() {
  const hash = typeof window !== "undefined" ? window.location.hash : "";
  return (
    <div>
      <nav className="border-b px-6 py-3">
        <div className="mx-auto flex max-w-6xl items-center gap-6">
          <span className="font-semibold">e2e-browser-gate</span>
        <a href="#/import_e2e-imported" className="text-sm text-gray-500 hover:text-gray-900">e2e-imported</a>
        </div>
      </nav>
      {!hash || hash === "#/import_e2e-imported" ? <Page1 /> : null}
    </div>
  );
}
