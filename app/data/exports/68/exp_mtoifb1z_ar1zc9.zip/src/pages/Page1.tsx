export default function Page1() {
  return (
    <div className="mx-auto" style={{ maxWidth: 1440 }}>
    <section className="w-full px-6 py-10 ">
      <h1 className="text-2xl font-semibold tracking-tight">登录</h1>
      <p className="text-sm leading-relaxed text-gray-600">欢迎回来,请登录您的账户</p>
      <input className="w-full rounded-lg border px-3 py-2 text-sm" placeholder="邮箱" type="text" />
      <input className="w-full rounded-lg border px-3 py-2 text-sm" placeholder="密码" type="text" />
      <button className="rounded-lg px-4 py-2 text-sm font-medium bg-gray-900 text-white">登录</button>
      <input className="size-4 rounded border" type="checkbox" />
    </section>
    </div>
  );
}
