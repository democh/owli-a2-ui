import Page1 from "./pages/Page1";
import Page2 from "./pages/Page2";
import Page3 from "./pages/Page3";
import Page4 from "./pages/Page4";

export default function App() {
  const hash = typeof window !== "undefined" ? window.location.hash : "";
  return (
    <div>
      <nav className="border-b px-6 py-3">
        <div className="mx-auto flex max-w-6xl items-center gap-6">
          <span className="font-semibold">e2e-browser-gate</span>
        <a href="#/frame_page" className="text-sm text-gray-500 hover:text-gray-900">首页</a>
        <a href="#/frame_page" className="text-sm text-gray-500 hover:text-gray-900">首页</a>
        <a href="#/frame_page" className="text-sm text-gray-500 hover:text-gray-900">首页</a>
        <a href="#/import_e2e-imported" className="text-sm text-gray-500 hover:text-gray-900">e2e-imported</a>
        </div>
      </nav>
      {!hash || hash === "#/frame_page" ? <Page1 /> : null}
      {hash === "#/frame_page" ? <Page2 /> : null}
      {hash === "#/frame_page" ? <Page3 /> : null}
      {hash === "#/import_e2e-imported" ? <Page4 /> : null}
    </div>
  );
}
