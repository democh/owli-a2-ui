export default function Page2() {
  return (
    <div className="mx-auto" style={{ maxWidth: 1440 }}>
    <div className="flex-1 min-w-0">
      <header className="flex items-center justify-between border-b px-6 py-3"></header>
      <section className="px-6 py-20 text-center">用一句话，生成完整页面</section>
      <footer className="border-t px-6 py-8 text-sm text-gray-500"></footer>
    </div>
    </div>
  );
}
