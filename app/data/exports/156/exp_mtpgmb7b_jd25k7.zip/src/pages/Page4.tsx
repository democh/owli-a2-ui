export default function Page4() {
  return (
    <div className="mx-auto" style={{ maxWidth: 1440 }}>
    <section className="w-full px-6 py-10 ">
      <h1 className="text-2xl font-semibold tracking-tight">E2E 导入页</h1>
      <input className="w-full rounded-lg border px-3 py-2 text-sm" placeholder="搜索" type="text" />
      <button className="rounded-lg px-4 py-2 text-sm font-medium bg-gray-900 text-white">提交</button>
    </section>
    </div>
  );
}
