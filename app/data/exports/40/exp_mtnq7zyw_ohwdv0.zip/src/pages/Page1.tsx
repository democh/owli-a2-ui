export default function Page1() {
  return (
    <div className="mx-auto" style={{ maxWidth: 1440 }}>
    <section className="w-full px-6 py-10 ">
      <h2 className="text-2xl font-semibold tracking-tight">首页</h2>
    </section>
    </div>
  );
}
